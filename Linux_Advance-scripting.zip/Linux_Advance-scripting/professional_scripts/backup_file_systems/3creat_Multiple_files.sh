#!/bin/bash
# Author: Imran
# Date: 20/11/2023
# Discription:  Multiple Files with different NAme
# Date Modified: 20/11/2023

for i in {1..10}
do
    touch imran.$i
done    