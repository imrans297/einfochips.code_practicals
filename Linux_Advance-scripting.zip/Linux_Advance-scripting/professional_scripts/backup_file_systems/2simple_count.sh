#!/bin/bash
# Author: Imran
# Date: 20/11/2023
# Discription:  back up the file /etc and /var file system
# Date Modified: 20/11/2023

for i in {1..10}
do 
    echo $i
    sleep 1
done    