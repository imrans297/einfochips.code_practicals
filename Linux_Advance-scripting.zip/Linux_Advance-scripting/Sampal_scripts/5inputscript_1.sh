#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: Input/Output SCript waits for the user i/p
# Date Modified: 18/11/2023
a=`hostname`
echo Hello, my server name is $a
echo 
echo what is your name?
read b
echo
echo what is your Professional?
read c
echo
echo what is you Hobbies
read d
echo
echo Hello $b
echo Okay that Sounds Good Your Professional is $c
echo $d is your Hobbies
echo
echo END OF THE SCRIPT
