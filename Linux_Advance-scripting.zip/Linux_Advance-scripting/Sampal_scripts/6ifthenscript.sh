#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: If the statement
# Date Modified: 18/11/2023

count=100
if [ $count -eq 100 ]
then
 echo count is 100
else
 echo sorry count is not 100
fi 
