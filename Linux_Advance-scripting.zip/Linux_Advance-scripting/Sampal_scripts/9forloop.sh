#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: For_loop
# Date Modified: 19/11/2023

for i in 1 2 3 4 5 6
do
echo "Wellcome $i times"
done