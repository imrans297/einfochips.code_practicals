#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: Basic Admin_task or commands
# Date Modified: 18/11/2023
echo
echo This Script will run basic Administrative Commanda
echo
top | head -10
echo
df -h
echo
free -m
echo
uptime
echo
echo ENd of the Script
