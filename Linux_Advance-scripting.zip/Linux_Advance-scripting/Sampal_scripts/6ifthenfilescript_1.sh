#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: If the statement
# Date Modified: 18/11/2023
clear
count=100
if [ -e /home/imranshaikh/errr.txt ]
    then
    echo "File Exist"
    else
    echo "File Does not Exist"
fi 
