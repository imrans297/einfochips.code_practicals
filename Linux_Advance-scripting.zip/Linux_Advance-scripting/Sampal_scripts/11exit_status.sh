#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: Exist Status
# Date Modified: 19/11/2023

echo Hello 
echo $?

#0 = Ok or successfull
#1 = Minor Problem
#2 = Serious Trouble
#3-255 = Everything Else 