#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: This Script will Output "HEllo World" on the screen
# Date Modified: 18/11/2023
echo
echo Hello World
echo