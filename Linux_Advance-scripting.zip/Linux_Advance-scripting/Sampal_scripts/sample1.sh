#!/bin/bash

# Purpose Testing Script Format
# Date: 18/11/2023
# Modification: 18/11/2023

a='My name is Imran''

echo $a

date
df -h

	if {$a -eq file}
	then echo this
	else
	echo that
	fi	
