#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: Input/Output SCript waits for the user i/p
# Date Modified: 18/11/2023

echo Hello, my name is Imran 
echo 
echo what is your name?
read namecont
echo
echo Hello $namecont
echo

echo END OF THE SCRIPT