#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: Run basic Linux TAsk
# Date Modified: 18/11/2023

echo
echo this script will run a few basic tasks
echo
pwd
echo
ls
echo
whoami
echo
date
echo
cal
echo
touch a b c
echo END OF Script