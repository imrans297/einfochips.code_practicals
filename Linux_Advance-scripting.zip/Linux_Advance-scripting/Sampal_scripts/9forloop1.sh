#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: this script will o/p imran with different actions
# Date Modified: 19/11/2023

for i in eat run jump play
do
echo see Imran $i
done