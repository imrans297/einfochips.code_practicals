#!/bin/bash
# Author: Imran
# Date: 18/11/2023
# Discription: Defining Variables
# Date Modified: 18/11/2023

p=pwd
l=ls
w=whoami
d=date
c='cal 2023'

echo Run Variables Tasks
echo
$p
$l
$w
$d
$c

echo END OF THE SCRIPT